# MedMoneyShow Thumbnail Generator v4

🎙️ AI-powered YouTube thumbnail generator for **@medicineandmoneyshow** (Dr. J. Ryan Smolarz)

## Features

- **Transcript Analysis**: Paste your podcast transcript, AI extracts key themes and generates matching backgrounds
- **Procedural Backgrounds**: Dynamic canvas-rendered backgrounds (no external image generation APIs)
- **Multiple Layouts**: Two-face (guest), solo left/right, centered text
- **Brand Presets**: Orange, cyan, purple accent colors
- **Export**: 1280×720 PNG ready for YouTube

## Quick Deploy to Replit

### Step 1: Create New Repl
1. Go to [replit.com](https://replit.com)
2. Click **+ Create Repl**
3. Choose **Import from GitHub** or **Upload folder**
4. Upload this entire folder

### Step 2: Add Your API Key
1. Click the **Secrets** tab (lock icon) in the left sidebar
2. Add a new secret:
   - **Key**: `ANTHROPIC_API_KEY`
   - **Value**: Your Anthropic API key from [console.anthropic.com](https://console.anthropic.com/)

### Step 3: Run
1. Click the **Run** button
2. Your app will be live at `https://your-repl-name.your-username.repl.co`

## Local Development

```bash
# Install dependencies
npm install

# Create .env file
cp .env.example .env
# Edit .env and add your ANTHROPIC_API_KEY

# Start server
npm start
# or for development with auto-reload:
npm run dev
```

Visit `http://localhost:3000`

## Project Structure

```
├── server.js          # Express backend (handles Anthropic API calls)
├── public/
│   └── index.html     # Complete frontend UI
├── package.json       # Dependencies
├── .replit            # Replit run configuration
├── replit.nix         # Nix environment (Node.js 20)
├── .env.example       # Environment template
└── README.md          # This file
```

## API Endpoints

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/api/analyze-transcript` | POST | Analyzes transcript, returns themes & suggested headline |
| `/api/generate-background` | POST | Generates procedural background parameters |
| `/api/health` | GET | Health check with API key validation |

## Environment Variables

| Variable | Required | Description |
|----------|----------|-------------|
| `ANTHROPIC_API_KEY` | Yes | Your Anthropic API key |
| `PORT` | No | Server port (default: 3000) |

## Usage

1. **Quick Start**: Select a background preset and customize text
2. **AI Generation**: Enter a prompt and click "Generate AI Background"
3. **Transcript Mode**: Paste your podcast transcript, click "Analyze & Generate"
4. **Export**: Click "Export 1280×720" to download your thumbnail

## Credits

Built for **THE MEDICINE AND MONEY SHOW LLC** | Dr. J. Ryan Smolarz

---

*Powered by Claude AI from Anthropic*
