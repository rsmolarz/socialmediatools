/**
 * MedMoneyShow Thumbnail Generator - Backend Server
 * Secure API proxy for Anthropic API calls
 * 
 * Environment Variables Required:
 * - ANTHROPIC_API_KEY: Your Anthropic API key
 * - PORT: Server port (defaults to 3000)
 */

const express = require('express');
const cors = require('cors');
const path = require('path');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(express.json({ limit: '10mb' }));
app.use(express.static('public'));

// Health check
app.get('/api/health', (req, res) => {
    res.json({ 
        status: 'ok', 
        hasApiKey: !!process.env.ANTHROPIC_API_KEY,
        timestamp: new Date().toISOString()
    });
});

// Proxy endpoint for transcript analysis
app.post('/api/analyze-transcript', async (req, res) => {
    if (!process.env.ANTHROPIC_API_KEY) {
        return res.status(500).json({ error: 'API key not configured' });
    }

    try {
        const { transcript } = req.body;
        
        if (!transcript) {
            return res.status(400).json({ error: 'Transcript is required' });
        }

        const response = await fetch('https://api.anthropic.com/v1/messages', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'x-api-key': process.env.ANTHROPIC_API_KEY,
                'anthropic-version': '2023-06-01'
            },
            body: JSON.stringify({
                model: 'claude-sonnet-4-20250514',
                max_tokens: 1000,
                messages: [
                    {
                        role: 'user',
                        content: `Analyze this podcast transcript and extract the key themes for creating a YouTube thumbnail background.

TRANSCRIPT:
${transcript.substring(0, 3000)}

Based on this transcript, provide:
1. A list of 3-5 key visual themes/concepts that would make a good thumbnail background
2. A suggested prompt for generating a procedural background
3. Recommended headline text (3 lines for the thumbnail)
4. Best style and mood settings

Respond ONLY with this JSON:
{
    "themes": ["theme1", "theme2", "theme3"],
    "backgroundPrompt": "description for procedural background generation",
    "suggestedHeadline": ["line1", "line2", "line3"],
    "style": "futuristic|abstract|cosmic|cyberpunk|medical|financial",
    "mood": "brand|neon|dark|gold|tech-blue",
    "visualElements": "network|particles|hexagons|waves|grid|lines"
}`
                    }
                ]
            })
        });

        const data = await response.json();
        
        if (data.error) {
            console.error('Anthropic API error:', data.error);
            return res.status(500).json({ error: data.error.message || 'API error' });
        }

        // Parse the response
        try {
            const content = data.content[0].text;
            const analysis = JSON.parse(content);
            res.json(analysis);
        } catch (parseError) {
            console.error('Parse error:', parseError);
            res.status(500).json({ error: 'Failed to parse analysis response' });
        }

    } catch (error) {
        console.error('Server error:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

// Proxy endpoint for background generation
app.post('/api/generate-background', async (req, res) => {
    if (!process.env.ANTHROPIC_API_KEY) {
        return res.status(500).json({ error: 'API key not configured' });
    }

    try {
        const { prompt, style, mood } = req.body;

        const response = await fetch('https://api.anthropic.com/v1/messages', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'x-api-key': process.env.ANTHROPIC_API_KEY,
                'anthropic-version': '2023-06-01'
            },
            body: JSON.stringify({
                model: 'claude-sonnet-4-20250514',
                max_tokens: 500,
                messages: [
                    {
                        role: 'user',
                        content: `You are a procedural graphics designer. Create parameters for a futuristic thumbnail background.
The user wants: "${prompt || 'futuristic wealth and medicine theme'}"
Style: ${style || 'futuristic'}
Color mood: ${mood || 'brand'}

Generate a JSON object with these exact fields for creating a procedural canvas background:
{
    "gradientColors": ["#hex1", "#hex2", "#hex3"],  // 3 dark colors for gradient background - MUST be very dark (value < 30)
    "particleColor": "#hex",  // main particle/element color
    "glowColor": "#hex",  // glow/highlight color
    "elementType": "circles|lines|hexagons|waves|grid|particles|network",  // main element type
    "density": 0.1-1.0,  // how many elements (0.1=sparse, 1.0=dense)
    "movement": "radial|linear|spiral|random|pulse",  // element pattern
    "overlayPattern": "none|grid|scan|noise",  // optional overlay
    "accentElements": ["text", "symbols", "shapes"],  // what accent elements to include (max 2)
    "seed": 12345  // random seed for reproducibility
}

IMPORTANT: The background base MUST be very dark/black. Use dark gradient colors like #0a0a0a, #0f0f1a, #0a1020, etc.
Brand colors to incorporate: Orange #F04F25, Cyan #00B0F0, Purple #4B0082

RESPOND WITH ONLY THE JSON OBJECT, NO OTHER TEXT.`
                    }
                ]
            })
        });

        const data = await response.json();
        
        if (data.error) {
            console.error('Anthropic API error:', data.error);
            return res.status(500).json({ error: data.error.message || 'API error' });
        }

        // Parse the response
        try {
            const content = data.content[0].text;
            const params = JSON.parse(content);
            res.json(params);
        } catch (parseError) {
            console.error('Parse error:', parseError);
            // Return default params on parse error
            res.json(getDefaultParams(style, mood));
        }

    } catch (error) {
        console.error('Server error:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

// Helper function for default params
function getDefaultParams(style, mood) {
    const styleParams = {
        futuristic: { elementType: 'network', movement: 'radial', overlayPattern: 'grid' },
        abstract: { elementType: 'waves', movement: 'spiral', overlayPattern: 'noise' },
        cosmic: { elementType: 'particles', movement: 'radial', overlayPattern: 'none' },
        cyberpunk: { elementType: 'grid', movement: 'linear', overlayPattern: 'scan' },
        medical: { elementType: 'hexagons', movement: 'pulse', overlayPattern: 'grid' },
        financial: { elementType: 'lines', movement: 'linear', overlayPattern: 'grid' }
    };
    
    const moodColors = {
        brand: { gradientColors: ['#000000', '#0a0a1a', '#050510'], particleColor: '#F04F25', glowColor: '#00B0F0' },
        neon: { gradientColors: ['#000000', '#050510', '#0a0515'], particleColor: '#ff00ff', glowColor: '#00ffff' },
        dark: { gradientColors: ['#000000', '#0a0a0a', '#050505'], particleColor: '#4B0082', glowColor: '#F04F25' },
        gold: { gradientColors: ['#000000', '#0a0a05', '#0f0f08'], particleColor: '#ffd700', glowColor: '#ff8c00' },
        'tech-blue': { gradientColors: ['#000000', '#000510', '#000a18'], particleColor: '#00B0F0', glowColor: '#4B0082' }
    };
    
    const sp = styleParams[style] || styleParams.futuristic;
    const mc = moodColors[mood] || moodColors.brand;
    
    return {
        ...mc,
        ...sp,
        density: 0.6,
        accentElements: ['shapes'],
        seed: Math.floor(Math.random() * 100000)
    };
}

// Serve the main app
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Start server
app.listen(PORT, '0.0.0.0', () => {
    console.log(`
╔════════════════════════════════════════════════════════════╗
║   MedMoneyShow Thumbnail Generator Server                  ║
╠════════════════════════════════════════════════════════════╣
║   🚀 Server running at http://localhost:${PORT}              ║
║   ${process.env.ANTHROPIC_API_KEY ? '✅ API Key configured' : '❌ API Key NOT configured - check .env'}                              ║
╚════════════════════════════════════════════════════════════╝
    `);
});
